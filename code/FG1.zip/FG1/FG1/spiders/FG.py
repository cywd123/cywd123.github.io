import scrapy
from FG1.items import Fg1Item

class FgSpider(scrapy.Spider):
    name = "FG"
    allowed_domains = ["fitgirl-repacks.site"]
    start_urls = ["http://fitgirl-repacks.site/"]

    def parse(self, response):
        for i in range(1,350):
            yield scrapy.Request("https://fitgirl-repacks.site/page/"+str(i)+'/',callback=self.parse_page)
        pass
    def parse_page(self, response):
        for each in response.xpath("//article"):
            item=Fg1Item()
            item['tle']=each.xpath("header/h1/a/text()").extract()
            item['info']=each.xpath("div/ul[1]").extract()
            yield item
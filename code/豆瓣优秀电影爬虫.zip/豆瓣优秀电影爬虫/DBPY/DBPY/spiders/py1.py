import scrapy
from DBPY.items import DbpyItem

class Py1Spider(scrapy.Spider):
    name = "py1"
    allowed_domains = ["movie.douban.com"]
    start_urls = ["https://movie.douban.com/top250"]

    def parse(self, response):
        for each in response.xpath("/html/body/div[3]/div[1]/div/div[1]/ol/li"):
            item=DbpyItem()
            item['name']=each.xpath("div/div[2]/div[1]/a/span[1]/text()").extract()
            item['star']=each.xpath("div/div[2]/div[2]/div/span[2]/text()").extract()
            item['url']=each.xpath("div/div[2]/div[1]/a/@href").extract()
            item['pj']=each.xpath("div/div[2]/div[2]/p[2]/span/text()").extract()
            item['picurl']=each.xpath("div/div[1]/a/img/@src").extract()
            item['info']=each.xpath("div/div[2]/div[2]/p[1]").extract()
            yield item
        next_url=response.xpath("//span[@class='next']/a/@href").extract()
        yield scrapy.Request('https://movie.douban.com/top250'+next_url[0],callback=self.parse)
        pass

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DbpyItem(scrapy.Item):
    name=scrapy.Field()
    star=scrapy.Field()
    url=scrapy.Field()
    pj=scrapy.Field()
    picurl=scrapy.Field()
    info=scrapy.Field()
    pass

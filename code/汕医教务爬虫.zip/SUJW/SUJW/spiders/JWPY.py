import scrapy
from SUJW.items import SujwItem
from bs4 import BeautifulSoup

class JwpySpider(scrapy.Spider):
    name = "JWPY"
    allowed_domains = ["jiaowu.med.stu.edu.cn"]
    start_urls = ["https://jiaowu.med.stu.edu.cn/3/list_3_1.html"]

    def parse(self, response):
        url=response.xpath("//a[text()='下一页']/@href").extract()
        url="https://jiaowu.med.stu.edu.cn"+str(url[0][2:])
        yield scrapy.Request(url,callback=self.parse)
        for each in response.xpath("//div[@class='list_center_art_title1']"):
            url="https://jiaowu.med.stu.edu.cn"+str(each.xpath("a/@href").extract()[0][2:]) 
            time=each.xpath("span/text()").extract()
            name=each.xpath("a/text()").extract()
            yield scrapy.Request(url, meta={"time":time ,"name":name,"url":url } ,callback=self.page)
        pass
    def page(self, response):
        item=SujwItem()
        item["name"]=response.meta["name"]
        item["url"]=response.meta["url"]
        item["time"]=response.meta["time"]
        item["info"]=BeautifulSoup(str(response.xpath("/html/body/div[5]/div[1]/div[2]/div[4]").extract()), "html.parser").get_text()
        yield item
        yield 

